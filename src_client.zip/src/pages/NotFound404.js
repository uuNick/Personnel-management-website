import React from 'react'
import NotFound from '../components/Not_Found/Not_found'

const NotFound404 = () => {
  return (
    <NotFound/>
  );
}
export default NotFound404;